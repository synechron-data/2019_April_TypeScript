function Check() {
    var i = 0;
    if (true) {
        var i_1 = 100;
    }
    return i;
}
console.log(Check());
