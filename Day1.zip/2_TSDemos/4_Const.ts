// const test;

// const env = "production";
// env = "development";
// const env = "development";

// if(true){
//     const env = "development";
// }

const obj = { id: 1, name: "ABC" };
console.log(obj);
obj.id = 10;
console.log(obj);
// obj = {};