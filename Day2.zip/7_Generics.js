function getLength(arg) {
    return arg.length;
}
getLength("ABC");
getLength(["ABC"]);
//# sourceMappingURL=7_Generics.js.map