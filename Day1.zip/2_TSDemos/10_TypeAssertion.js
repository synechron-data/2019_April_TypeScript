var myData = "This is just for check...";
var l1 = myData.length;
console.log(l1);
var l2 = myData.length;
console.log(l2);
var l3 = myData.length;
console.log(l3);
var l4 = myData.toFixed();
console.log(l4);
