var myTuple = [10, "ABC"];
//# sourceMappingURL=2_Tuple.js.map