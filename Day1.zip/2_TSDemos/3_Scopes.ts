// // var i = 10;
// // var i = 20;

// // console.log(i);

// var i = 10;
// console.log("Before, i is:", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is:", i);
// }

// console.log("After, i is:", i);

// -------------------------------------- TypeScript
// let i = 10;
// let i = 20;

// console.log(i);

// var i = 10;
// console.log("Before, i is:", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside, i is:", i);
// }

// console.log("After, i is:", i);


function Check() {
    var i = 0;

    if (true) {
        let i = 100;
    }

    return i;
}

console.log(Check());