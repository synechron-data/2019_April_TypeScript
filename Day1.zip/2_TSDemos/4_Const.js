var obj = { id: 1, name: "ABC" };
console.log(obj);
obj.id = 10;
console.log(obj);
