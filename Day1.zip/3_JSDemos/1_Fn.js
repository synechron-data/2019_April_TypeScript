function Hello(name) {
    console.log("Hello,", name);
}

Hello("Manish");
Hello("Manish", "Sharma");
Hello();