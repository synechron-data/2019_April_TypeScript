var a;
a = 10;
function add(x, y) {
    return x + y;
}
var r1 = add(2, 3);
