function add1(x, y) {
    return x + y;
}
var add2 = function (x, y) {
    return x + y;
};
var add3;
add3 = function (x, y) {
    return x + y;
};
var age;
age = 10;
var add4;
add4 = function (x, y) {
    return x + y;
};
var add5;
add5 = function (x, y) {
    return x + y;
};
var add6;
add6 = function (x, y) { return x + y; };
var arr = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];
var j = 10;
console.log(j);
console.log(typeof j);
console.log(add1);
console.log(typeof add1);
